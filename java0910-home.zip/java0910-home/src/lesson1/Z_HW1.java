package lesson1;

/*
Вывести на экран текст:
Привет, меня зовут <Имя>!
Я живу в Санкт-Петербурге.
 */
public class Z_HW1 {
    public static void main(String[] args) {

    }
}
