package lesson1;

public class C_Str {
    static void str() {
        // Класс String
        String s = "Строка с информацией";
        System.out.println(s);
        System.out.println(s.length());
    }
}
