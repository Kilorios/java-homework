package lesson1;

public class Lesson1 {
    public static void main(String[] args) {
//        A_Output.output();
//        B_Vars.novars();
//        B_Vars.vars();
//        B_Vars.prim_types();
//        B_Vars.task1();
//        B_Vars.ieee_float();
//        B_Vars.priv();
//        C_Str.str();
//        D_Input.scanner();
        D_Input.scanner2();
    }
}
