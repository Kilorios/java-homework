package lesson1;

/*
Создать и инициализировать значениями три переменных: int, long и float
Вывести на экран их произведение в одной строке, сумму - в другой
 */
public class Z_HW2 {
    public static void main(String[] args) {

    }
}
