package lesson1;

/*
Спросить у пользователя два целых числа int
Вывести на экран их сумму, разность, произведение, деление и остаток от деления
Знаки операций: +, -, *, /, %
 */
public class Z_HW3 {
    public static void main(String[] args) {
        System.out.println(5/2);
    }
}
