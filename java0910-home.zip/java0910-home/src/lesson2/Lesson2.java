package lesson2;


public class Lesson2 {
    public static void main(String[] args) {
        //A_Actions.actions();
        //A_Actions.log_actions();
        //B_IfElse.if_else();
        //B_IfElse.task1();
        //B_IfElse.task2();
        //B_IfElse.task3();
        //B_IfElse.inner();
        //C_switch.noswitch();
        //C_switch.noswitch2();
        //C_switch.withswitch();
        //D_Arrays.arrays();
        //D_Arrays.task3();
        //E_Loops.whileLoop();
        //E_Loops.doWhile();
        E_Loops.forLoop();
    }
}
