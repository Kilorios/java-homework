package lesson3;

public class Lesson3 {
    public static void main(String[] args) {
        //A_ArraysAndLoops.traverseArray();
        //A_ArraysAndLoops.workWithArr();
        //A_ArraysAndLoops.task1();
        //A_ArraysAndLoops.travExample1();
        //A_ArraysAndLoops.travExample2();
        //A_ArraysAndLoops.maximum();
        //A_ArraysAndLoops.minimum();
        //A_ArraysAndLoops.sum();
        //A_ArraysAndLoops.prod();
        //A_ArraysAndLoops.maximumIndex();
        //B_MultiArrays.multiarrays();
        //C_Classes.classes();
        //C_Classes.constructors();
        //C_Classes.methods();
        //D_Vidimost.example();
    }
}
